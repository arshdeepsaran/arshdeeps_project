let count = 0;

const data = {
    labels: [],
    datasets: []
  };

const config = {
  type: 'line',
  data: data,
  options: {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Number of Employees (in thousands)'
      }
    }
  }
};

const SectorCode = {
"0000": "Total Non-farm", "0500": "Total Private","0600": "Goods Producing", "0700": "Service Providing",  "0800": "Private service-providing", "1000": "Mining and logging", "2000": "Construction", "3000": "Manufacturing", "3100": "Durable Goods", "3200": "Non-durable Goods", "4000": "Trade, Transportation and Utilities", "4142": "Wholesale trade", "4200": "Retail trade", "4300": "Transportation and Warehousing", "4422": "Utilities", "5000": "Information", "5500": "Financial activities", "6000": "Professional and Business Services",
"6500": "Education and Health Services", "7000": "Leisure and Hospitality", "8000": "Other services", "9000": "Government"
};
let SectorCodeKeys = Object.keys(SectorCode);


const CHARTCOLOR = {
  red: 'rgb(255, 99, 132)',
  orange: 'rgb(255, 159, 64)',
  yellow: 'rgb(255, 205, 86)',
  green: 'rgb(75, 192, 192)',
  blue: 'rgb(54, 162, 235)',
  purple: 'rgb(153, 102, 255)',
  grey: 'rgb(201, 203, 207)',
  pink: 'rgb(255, 102, 178)',
  bright_green: 'rgb(182, 240, 187)',
  bright_blue: 'rgb(153, 204, 255)',
  neon_purple: 'rgb(277, 202, 255)',
  litegrey: 'rgb(192, 192, 192)',
  neongreen: 'rgb(0, 255, 0)',
};
let CHARTCOLOR_KEYS = Object.keys(CHARTCOLOR);
 
const CHARTCOLOR_HALF = {
  red: 'rgba(255, 99, 132, 0.5)',
  orange: 'rgba(255, 159, 64, 0.5)',
  yellow: 'rgba(255, 205, 86, 0.5)',
  green: 'rgba(75, 192, 192, 0.5)',
  blue: 'rgba(54, 162, 235, 0.5)',
  purple: 'rgba(153, 102, 255, 0.5)',
  grey: 'rgba(201, 203, 207, 0.5)',
  pink: 'rgba(255, 102, 178, 0.5)',
  bright_green: 'rgba(182, 240, 187, 0.5)',
  bright_blue: 'rgba(153, 204, 255, 0.5)',
  neon_purple: 'rgba(277, 202, 255, 0.5)',
  litegrey: 'rgba(192, 192, 192, 0.5)',
  neongreen: 'rgba(0, 255, 0, 0.5)',
};
let CHARTCOLOR_HALF_KEY = Object.keys(CHARTCOLOR_HALF);

let flag = false;
function responseHandler() {
  if (this.status == 200) {
    let dataArray = this.response.Results.series[0].data;
let seriesID = this.response.Results.series[0].seriesID;
  let SectorCodeline = {
label: "",
data:[],
borderColor: "",
backgroundColor: "",
hidden:true
}

SectorCodeline.label = (SectorCode[seriesID.substring(3,7)]);
SectorCodeline.borderColor = (CHARTCOLOR_KEYS[count]);
SectorCodeline.backgroundColor = (CHARTCOLOR_HALF_KEY[count]);
if(flag == false){
for (let i = dataArray.length -1; i >= 0; i--) {
data.labels.push(dataArray[i].periodName + " " + dataArray[i].year);
flag = true;
}}
for(let i = dataArray.length -1; i >= 0; i--) {
SectorCodeline.data.push(dataArray[i].value);

}

data.datasets.push(SectorCodeline);
count++

  console.log(this.response);
  }else {
  console.log ("error");
  }
}

const myChart = new Chart(
  document.getElementById('myChart'),
    config);


for (i = 0; i < SectorCodeKeys.length; i++){
let call = new XMLHttpRequest()
call.addEventListener("load", responseHandler);
let apiLink = "https://api.bls.gov/publicAPI/v2/timeseries/data/CEU";
let apiCode = "000001?registrationkey=";
let apiKey = ""

if(apiKey == ""){
  alert("Registration Key is negative, please go to script.js and assign a string value to variable 'apiKey'")
}

call.open("GET", apiLink + SectorCodeKeys[i] + apiCode + apiKey);
call.responseType = "json";
call.send();
}
